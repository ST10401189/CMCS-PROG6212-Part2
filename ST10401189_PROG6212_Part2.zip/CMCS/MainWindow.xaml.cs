﻿using CMCS.Views;
using System;
using System.Windows;
using System.Windows.Navigation;

namespace CMCS
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            // Show login screen when application starts
            ShowLoginScreen();
        }

        private void ShowLoginScreen()
        {
            // Create and show the login view
            var loginView = new LoginView();
            loginView.LoginSuccessful += OnLoginSuccessful;
            MainFrame.Content = loginView;
        }

        private void OnLoginSuccessful(object? sender, UserRoleEventArgs e) // Add ? to make nullable
        {
            // When login is successful, show the main dashboard
            ShowDashboard(e.UserRole);
        }

        private void ShowDashboard(string userRole)
        {
            var dashboard = new DashboardView(userRole);
            dashboard.LogoutRequested += OnLogoutRequested;
            MainFrame.Content = dashboard;
        }

        private void OnLogoutRequested(object? sender, EventArgs e) // Add ? to make nullable
        {
            // When logout is requested, show login screen again
            ShowLoginScreen();
        }
    }
}