﻿using CMCS.Models;
using CMCS.Services;
using System;

namespace CMCS.Tests
{
    public class ClaimServiceTests
    {
        public void SubmitClaim_ValidClaim_ReturnsTrue()
        {
            // Arrange
            var service = new DataService();
            var claim = new Claim { HoursWorked = 40, HourlyRate = 50 };

            // Act
            var result = service.SubmitClaim(claim);

            // Assert
            Console.WriteLine($"Test Result: {result}");
            // In a real test: Assert.IsTrue(result);
        }

        public void CalculateTotal_HoursAndRate_CorrectTotal()
        {
            // Arrange
            var claim = new Claim { HoursWorked = 40, HourlyRate = 50 };

            // Act & Assert
            var expectedTotal = 2000m;
            if (claim.TotalAmount == expectedTotal)
            {
                Console.WriteLine("CalculateTotal test: PASSED");
            }
            else
            {
                Console.WriteLine($"CalculateTotal test: FAILED - Expected {expectedTotal}, got {claim.TotalAmount}");
            }
        }
    }
}