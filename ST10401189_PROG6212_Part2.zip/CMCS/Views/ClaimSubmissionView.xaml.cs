﻿using Microsoft.Win32;
using System;
using System.Windows;
using System.Windows.Controls;
using CMCS.ViewModels;
using CMCS.Models;

namespace CMCS.Views
{
    public partial class ClaimSubmissionView : UserControl
    {
        private ClaimViewModel _viewModel;

        public ClaimSubmissionView()
        {
            InitializeComponent();
            _viewModel = new ClaimViewModel();
            DataContext = _viewModel;
        }

        private void UploadDocument_Click(object sender, RoutedEventArgs e)
        {
            var openFileDialog = new OpenFileDialog
            {
                Filter = "Documents (*.pdf;*.docx;*.xlsx)|*.pdf;*.docx;*.xlsx|All Files (*.*)|*.*",
                Title = "Select Supporting Document"
            };

            if (openFileDialog.ShowDialog() == true)
            {
                // Check file size (5MB limit)
                var fileInfo = new System.IO.FileInfo(openFileDialog.FileName);
                if (fileInfo.Length > 5 * 1024 * 1024)
                {
                    MessageBox.Show("File size must be less than 5MB.", "File Too Large",
                                  MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                // Save file and update claim
                _viewModel.CurrentClaim.DocumentPath = openFileDialog.FileName;
                DocumentNameText.Text = System.IO.Path.GetFileName(openFileDialog.FileName);

                MessageBox.Show("Document uploaded successfully!", "Success",
                              MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void CalculateTotal_Click(object sender, RoutedEventArgs e)
        {
            // Force refresh of the TotalAmount binding
            _viewModel.OnPropertyChanged(nameof(_viewModel.CurrentClaim.TotalAmount));

            MessageBox.Show($"Total Amount Calculated: R {_viewModel.CurrentClaim.TotalAmount:F2}",
                          "Calculation Complete", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void SubmitClaim_Click(object sender, RoutedEventArgs e)
        {
            if (ValidateClaim())
            {
                // Save claim to database
                SaveClaim(_viewModel.CurrentClaim);
                MessageBox.Show("Claim submitted successfully!", "Success",
                              MessageBoxButton.OK, MessageBoxImage.Information);
                ClearForm();
            }
        }

        private bool ValidateClaim()
        {
            // Validation for Module
            if (_viewModel.CurrentClaim.ModuleId == 0)
            {
                MessageBox.Show("Please select a module.", "Validation Error",
                              MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            // Validation for Hours Worked
            if (_viewModel.CurrentClaim.HoursWorked <= 0)
            {
                MessageBox.Show("Please enter valid hours worked (greater than 0).", "Validation Error",
                              MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            // Validation for Hourly Rate
            if (_viewModel.CurrentClaim.HourlyRate <= 0)
            {
                MessageBox.Show("Please enter valid hourly rate (greater than 0).", "Validation Error",
                              MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            // Validation for Document (optional but recommended)
            if (string.IsNullOrEmpty(_viewModel.CurrentClaim.DocumentPath))
            {
                var result = MessageBox.Show("No supporting document uploaded. Continue without document?",
                                           "Missing Document",
                                           MessageBoxButton.YesNo,
                                           MessageBoxImage.Question);
                if (result == MessageBoxResult.No)
                {
                    return false;
                }
            }

            return true;
        }

        private void SaveClaim(Claim claim)
        {
            try
            {
                // TODO: Replace with actual database save logic
                // For now, we'll just display the claim details

                string moduleName = "Unknown Module";
                foreach (var module in _viewModel.AvailableModules)
                {
                    if (module.ModuleId == claim.ModuleId)
                    {
                        moduleName = module.ModuleName;
                        break;
                    }
                }

                string claimDetails = $@"Claim Details:
Module: {moduleName}
Hours Worked: {claim.HoursWorked}
Hourly Rate: R {claim.HourlyRate:F2}
Total Amount: R {claim.TotalAmount:F2}
Notes: {claim.Notes}
Document: {(string.IsNullOrEmpty(claim.DocumentPath) ? "None" : System.IO.Path.GetFileName(claim.DocumentPath))}";

                Console.WriteLine("Claim saved to database:");
                Console.WriteLine(claimDetails);

                // In a real application, you would save to a database here
                // Example:
                // using (var context = new ApplicationDbContext())
                // {
                //     context.Claims.Add(claim);
                //     context.SaveChanges();
                // }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error saving claim: {ex.Message}", "Error",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ClearForm()
        {
            // Reset the form
            _viewModel.CurrentClaim = new Claim
            {
                MonthYear = DateTime.Now,
                Status = "Submitted"
            };
            DocumentNameText.Text = string.Empty;

            // Clear any bindings
            var comboBox = FindName("ModuleComboBox") as ComboBox;
            if (comboBox != null)
                comboBox.SelectedIndex = -1;
        }
    }
}