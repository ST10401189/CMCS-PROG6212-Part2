﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace CMCS.Views
{
    public partial class LoginView : UserControl
    {
        public event EventHandler<UserRoleEventArgs>? LoginSuccessful; // Add ? to make nullable

        public LoginView()
        {
            InitializeComponent();

            // Set focus to username field
            Loaded += (s, e) => UsernameTextBox.Focus();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string username = UsernameTextBox.Text.Trim();
            string password = PasswordBox.Password;

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                ShowError("Please enter both username and password.");
                return;
            }

            // Simple authentication (replace with real authentication)
            string? userRole = AuthenticateUser(username, password); // Add ? to make nullable

            if (userRole != null)
            {
                // Login successful
                LoginSuccessful?.Invoke(this, new UserRoleEventArgs(userRole));
            }
            else
            {
                ShowError("Invalid username or password. Please try again.");
            }
        }

        private string? AuthenticateUser(string username, string password) // Add ? to make nullable
        {
            // Simple demo authentication - replace with real database check
            var users = new[]
            {
                new { Username = "lecturer", Password = "pass123", Role = "Lecturer" },
                new { Username = "coordinator", Password = "pass123", Role = "Coordinator" },
                new { Username = "manager", Password = "pass123", Role = "Manager" }
            };

            var user = Array.Find(users, u =>
                u.Username.Equals(username, StringComparison.OrdinalIgnoreCase) &&
                u.Password == password);

            return user?.Role;
        }

        private void ShowError(string message)
        {
            ErrorMessage.Text = message;
            ErrorMessage.Visibility = Visibility.Visible;
        }
    }

    public class UserRoleEventArgs : EventArgs
    {
        public string UserRole { get; }

        public UserRoleEventArgs(string userRole)
        {
            UserRole = userRole;
        }
    }
}