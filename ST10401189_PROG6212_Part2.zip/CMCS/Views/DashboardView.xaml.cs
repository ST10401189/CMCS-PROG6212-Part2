﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace CMCS.Views
{
    public partial class DashboardView : UserControl
    {
        private string _userRole;
        public event EventHandler? LogoutRequested;

        public DashboardView(string userRole)
        {
            InitializeComponent();
            _userRole = userRole;
            Loaded += DashboardView_Loaded;
        }

        private void DashboardView_Loaded(object sender, RoutedEventArgs e)
        {
            UserRoleText.Text = _userRole;
            UpdateUIForUserRole();
        }

        private void UpdateUIForUserRole()
        {
            // Show/hide buttons based on user role
            switch (_userRole)
            {
                case "Lecturer":
                    SubmitClaimButton.Visibility = Visibility.Visible;
                    TrackClaimsButton.Visibility = Visibility.Visible;
                    ApproveClaimsButton.Visibility = Visibility.Collapsed;
                    WelcomeMessage.Text = "As a lecturer, you can submit new claims and track the status of your existing claims.";
                    break;

                case "Coordinator":
                    SubmitClaimButton.Visibility = Visibility.Collapsed;
                    TrackClaimsButton.Visibility = Visibility.Collapsed;
                    ApproveClaimsButton.Visibility = Visibility.Visible;
                    WelcomeMessage.Text = "As a programme coordinator, you can review and approve pending claims.";
                    break;

                case "Manager":
                    SubmitClaimButton.Visibility = Visibility.Collapsed;
                    TrackClaimsButton.Visibility = Visibility.Collapsed;
                    ApproveClaimsButton.Visibility = Visibility.Visible;
                    WelcomeMessage.Text = "As an academic manager, you can review and approve pending claims.";
                    break;
            }
        }

        private void SubmitClaimButton_Click(object sender, RoutedEventArgs e)
        {
            // Navigate to Claim Submission View
            var claimSubmissionView = new ClaimSubmissionView();
            var mainWindow = Application.Current.MainWindow as MainWindow;
            if (mainWindow != null)
            {
                mainWindow.MainFrame.Content = claimSubmissionView;
            }
        }

        private void TrackClaimsButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Track Claims feature will be implemented here!",
                          "Feature Coming Soon", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void ApproveClaimsButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Approve Claims feature will be implemented here!",
                          "Feature Coming Soon", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            LogoutRequested?.Invoke(this, EventArgs.Empty);
        }
    }
}