﻿using CMCS.Models;
using System.Collections.Generic;
using System.Linq;

namespace CMCS.Services
{
    public class DataService
    {
        private readonly List<Claim> _claims = new List<Claim>();
        private int _nextClaimId = 1;

        public bool SubmitClaim(Claim claim)
        {
            try
            {
                claim.ClaimId = _nextClaimId++;
                _claims.Add(claim);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public List<Claim> GetPendingClaims()
        {
            return _claims.Where(c => c.Status == "Submitted").ToList();
        }

        public List<Claim> GetAllClaims()
        {
            return _claims.ToList();
        }

        public bool UpdateClaimStatus(int claimId, string status)
        {
            var claim = _claims.FirstOrDefault(c => c.ClaimId == claimId);
            if (claim != null)
            {
                claim.Status = status;
                return true;
            }
            return false;
        }
    }
}