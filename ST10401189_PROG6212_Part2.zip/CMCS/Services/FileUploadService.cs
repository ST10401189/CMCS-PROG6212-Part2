﻿using System.IO;

public class FileUploadService
{
    private readonly string _uploadPath = "Uploads";

    public string UploadFile(string filePath)
    {
        if (!Directory.Exists(_uploadPath))
            Directory.CreateDirectory(_uploadPath);

        var fileName = Guid.NewGuid().ToString() + Path.GetExtension(filePath);
        var newPath = Path.Combine(_uploadPath, fileName);

        File.Copy(filePath, newPath);
        return newPath;
    }

    public bool IsValidFile(string filePath)
    {
        var allowedExtensions = new[] { ".pdf", ".docx", ".xlsx" };
        var maxSize = 5 * 1024 * 1024; // 5MB

        var fileInfo = new FileInfo(filePath);
        return allowedExtensions.Contains(fileInfo.Extension.ToLower()) &&
               fileInfo.Length <= maxSize;
    }
}