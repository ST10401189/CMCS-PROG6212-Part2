﻿using System;
using System.ComponentModel;

namespace CMCS.Models
{
    public class Claim : INotifyPropertyChanged
    {
        private decimal _hoursWorked;
        private decimal _hourlyRate;
        private string _status = "Submitted";
        private string _notes = string.Empty;
        private string _documentPath = string.Empty;

        public int ClaimId { get; set; }
        public int LecturerId { get; set; }
        public int ModuleId { get; set; }
        public DateTime MonthYear { get; set; } = DateTime.Now;

        public decimal HoursWorked
        {
            get => _hoursWorked;
            set { _hoursWorked = value; OnPropertyChanged(); OnPropertyChanged(nameof(TotalAmount)); }
        }

        public decimal HourlyRate
        {
            get => _hourlyRate;
            set { _hourlyRate = value; OnPropertyChanged(); OnPropertyChanged(nameof(TotalAmount)); }
        }

        public decimal TotalAmount => HoursWorked * HourlyRate;

        public string Status
        {
            get => _status;
            set { _status = value ?? string.Empty; OnPropertyChanged(); }
        }

        public string Notes
        {
            get => _notes;
            set { _notes = value ?? string.Empty; OnPropertyChanged(); }
        }

        public string DocumentPath
        {
            get => _documentPath;
            set { _documentPath = value ?? string.Empty; OnPropertyChanged(); }
        }

        public DateTime SubmittedDate { get; set; } = DateTime.Now;

        public event PropertyChangedEventHandler? PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}