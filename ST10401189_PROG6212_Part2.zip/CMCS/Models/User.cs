﻿using System.ComponentModel;

namespace CMCS.Models
{
    public class User : INotifyPropertyChanged
    {
        private string _username = string.Empty;
        private string _password = string.Empty;
        private string _role = string.Empty;

        public int UserId { get; set; }

        public string Username
        {
            get => _username;
            set { _username = value ?? string.Empty; OnPropertyChanged(); }
        }

        public string Password
        {
            get => _password;
            set { _password = value ?? string.Empty; OnPropertyChanged(); }
        }

        public string Role
        {
            get => _role;
            set { _role = value ?? string.Empty; OnPropertyChanged(); }
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}