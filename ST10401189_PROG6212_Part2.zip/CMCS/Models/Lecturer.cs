﻿using System.Collections.Generic;
using System.ComponentModel;

namespace CMCS.Models
{
    public class Lecturer : INotifyPropertyChanged
    {
        private string _name = string.Empty;
        private string _email = string.Empty;

        public int LecturerId { get; set; }

        public string Name
        {
            get => _name;
            set { _name = value ?? string.Empty; OnPropertyChanged(); }
        }

        public string Email
        {
            get => _email;
            set { _email = value ?? string.Empty; OnPropertyChanged(); }
        }

        public List<Claim> Claims { get; set; } = new List<Claim>();

        public event PropertyChangedEventHandler? PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}