﻿using System.ComponentModel;

namespace CMCS.Models
{
    public class Module : INotifyPropertyChanged
    {
        private string _moduleCode = string.Empty;
        private string _moduleName = string.Empty;

        public int ModuleId { get; set; }

        public string ModuleCode
        {
            get => _moduleCode;
            set { _moduleCode = value ?? string.Empty; OnPropertyChanged(); }
        }

        public string ModuleName
        {
            get => _moduleName;
            set { _moduleName = value ?? string.Empty; OnPropertyChanged(); }
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}