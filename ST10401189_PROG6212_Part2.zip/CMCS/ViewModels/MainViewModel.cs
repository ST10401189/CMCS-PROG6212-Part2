﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using CMCS.Models;

namespace CMCS.ViewModels
{
    public class MainViewModel : INotifyPropertyChanged
    {
        private ObservableCollection<Claim> _claims;

        public ObservableCollection<Claim> Claims
        {
            get => _claims;
            set { _claims = value; OnPropertyChanged(); }
        }

        public MainViewModel()
        {
            // Initialize claims collection
            _claims = new ObservableCollection<Claim>();

            // Load sample data for testing
            LoadSampleData();
        }

        private void LoadSampleData()
        {
            // Add some sample claims for testing
            Claims.Add(new Claim { ClaimId = 1, HoursWorked = 40, HourlyRate = 500, Status = "Submitted" });
            Claims.Add(new Claim { ClaimId = 2, HoursWorked = 35, HourlyRate = 450, Status = "Approved" });
            Claims.Add(new Claim { ClaimId = 3, HoursWorked = 45, HourlyRate = 480, Status = "Pending" });
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}