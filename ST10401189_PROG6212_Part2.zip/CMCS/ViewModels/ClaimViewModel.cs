﻿using CMCS.Models;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace CMCS.ViewModels
{
    public class ClaimViewModel : INotifyPropertyChanged
    {
        private Claim _currentClaim = new Claim();

        public Claim CurrentClaim
        {
            get => _currentClaim;
            set
            {
                _currentClaim = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(TotalAmountDisplay)); // Update total when claim changes
            }
        }

        // Helper property for display
        public string TotalAmountDisplay => $"R {CurrentClaim.TotalAmount:F2}";

        public ObservableCollection<Module> AvailableModules { get; set; } = new ObservableCollection<Module>();

        public ClaimViewModel()
        {
            // Initialize with some sample modules
            AvailableModules.Add(new Module { ModuleId = 1, ModuleCode = "PROG6212", ModuleName = "Programming 2" });
            AvailableModules.Add(new Module { ModuleId = 2, ModuleCode = "DATA6212", ModuleName = "Database Systems" });
            AvailableModules.Add(new Module { ModuleId = 3, ModuleCode = "WEDE5020", ModuleName = "Web Development" });
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        // Change from protected to public
        public void OnPropertyChanged([CallerMemberName] string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        // Helper method to refresh all properties
        public void RefreshAllProperties()
        {
            OnPropertyChanged(nameof(CurrentClaim));
            OnPropertyChanged(nameof(TotalAmountDisplay));
        }
    }
}